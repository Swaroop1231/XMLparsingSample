//
//  SSDemoCell.m
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSDemoCell.h"

@implementation SSDemoCell
@synthesize nameLabel,idLabel,activityLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
