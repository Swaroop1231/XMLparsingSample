//
//  SSViewController.h
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSDemoCell.h"
#import "SSObject.h"

@interface SSViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    UITableView *demoTableView;
}

@property(nonatomic,strong) IBOutlet UITableView *demoTableView;
@property(nonatomic,strong) NSMutableArray *demoArray;
@property(nonatomic,strong) IBOutlet SSDemoCell *democustomcell;


@end
