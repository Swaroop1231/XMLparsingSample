//
//  SSObject.h
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SSObject : NSObject



@property(nonatomic,strong) NSString *nameString;
@property(nonatomic,strong) NSString *idString;
@property(nonatomic,strong) NSString *activityString;

@property(nonatomic,strong) NSString *sectorString;
@property(nonatomic,strong) NSString *useString;
@property(nonatomic,strong) NSString *countryString;
@property(nonatomic,strong) NSString *townString;
@property(nonatomic,strong) NSString *PostedString;
@property(nonatomic,strong) NSString *loanAmountString;







@end
