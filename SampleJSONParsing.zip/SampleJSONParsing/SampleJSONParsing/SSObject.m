//
//  SSObject.m
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSObject.h"

@implementation SSObject

@synthesize nameString;
@synthesize idString;
@synthesize activityString;

@synthesize sectorString;
@synthesize useString;
@synthesize countryString;
@synthesize townString;
@synthesize PostedString;
@synthesize loanAmountString;

@end
