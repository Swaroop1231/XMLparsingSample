//
//  SSViewController.h
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSAppDelegate.h"
#import "SaveObject.h"

@interface SSViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    UITableView *xmlTblView;
    SSAppDelegate *appdelegate;
}

@property(nonatomic,strong) IBOutlet UITableView *xmlTblView;
@property(nonatomic,strong) SaveObject *myObj;


@end
