//
//  SaveObject.h
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SaveObject : NSObject
{
    NSString *titleSr;
    NSString *descStr;
    NSString *linkStr;
}

@property(nonatomic,strong) NSString *titleSr; 
@property(nonatomic,strong) NSString *descStr;
@property(nonatomic,strong) NSString *linkStr;




@end
