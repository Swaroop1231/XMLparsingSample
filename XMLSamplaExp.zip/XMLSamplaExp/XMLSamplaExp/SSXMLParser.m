//
//  SSXMLParser.m
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSXMLParser.h"

@implementation SSXMLParser
@synthesize myObject;
@synthesize currentString;

- (SSXMLParser *) initXMLParser
{
	self=[super init];
	
	appDelegate = (SSAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	return self;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
	attributes:(NSDictionary *)attributeDict

{
 
    if ([elementName isEqualToString:@"Resources"])
    {
        appDelegate.testMutableArray=[[NSMutableArray alloc]init];
    }
    
    if ([elementName isEqualToString:@"Resource"])
    {
        myObject=[[SaveObject alloc]init];
        
    }
    
    
    if ([elementName isEqualToString:@"Title"])
    {
        currentString=[[NSMutableString alloc]init];
        
    }
    
    if ([elementName isEqualToString:@"Description"])
    {
        currentString=[[NSMutableString alloc]init];
        
    }
    
    if ([elementName isEqualToString:@"Link"])
    {
        currentString=[[NSMutableString alloc]init];
        
    }



    
    
}


- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
        
    [currentString appendString:string];
    
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{

    if ([elementName isEqualToString:@"Title"])
    {
        
        myObject.titleSr=currentString;
        
    }
    
    if ([elementName isEqualToString:@"Description"])
    {
        myObject.descStr=currentString;

        
    }
    
    if ([elementName isEqualToString:@"Link"])
    {
        myObject.linkStr=currentString;

        
    }

    
   // NSLog(@"My string is %@",currentString);
    
    
    if ([elementName isEqualToString:@"Resource"])
    {
        
        [appDelegate.testMutableArray addObject:myObject];
        
    }
    
    if ([elementName isEqualToString:@"Resources"])
    {
        return ;
    }
    
    
   // NSLog(@"Array count is %d",[appDelegate.testMutableArray count]);
    
}

@end
