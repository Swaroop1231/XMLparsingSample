//
//  SSWebViewController.h
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SSWebViewController : UIViewController<UIWebViewDelegate>
{
    
    IBOutlet UIWebView *xmlWebView;
}

@property(nonatomic,strong) IBOutlet UIWebView *xmlWebView;
@property(nonatomic,strong) NSString *webURlStr;




@end
