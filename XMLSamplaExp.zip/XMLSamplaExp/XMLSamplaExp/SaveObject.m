//
//  SaveObject.m
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SaveObject.h"

@implementation SaveObject
@synthesize titleSr;
@synthesize descStr;
@synthesize linkStr;



@end
