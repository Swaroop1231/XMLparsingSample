//
//  SSSecViewController.m
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSSecViewController.h"

@interface SSSecViewController ()

@end

@implementation SSSecViewController

@synthesize sectorString;
@synthesize useString;
@synthesize countryString;
@synthesize townString;
@synthesize PostedString;
@synthesize loanAmountString;
@synthesize secObj;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title=secObj.nameString;
    [self getDetails];
    
}


-(void)getDetails
{
    
    useString.text= [NSString stringWithFormat:@"%@",secObj.useString ];
    sectorString.text=[NSString stringWithFormat:@"%@",secObj.sectorString];
    countryString.text=[NSString stringWithFormat:@"%@",secObj.countryString];
    townString.text=[NSString stringWithFormat:@"%@", secObj.townString];
    loanAmountString.text=[NSString stringWithFormat:@"%@", secObj.loanAmountString];
    
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
