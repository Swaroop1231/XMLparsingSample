//
//  SSXMLParser.h
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SSAppDelegate.h"
#import "SaveObject.h"

@interface SSXMLParser : NSObject
{
    
	NSMutableString *currentElementValue;
	
	SSAppDelegate *appDelegate;
	SaveObject *myObject;
}


@property(nonatomic,strong)	SaveObject *myObject;
@property(nonatomic,strong)	NSMutableString *currentString;


- (SSXMLParser *) initXMLParser;

@end
