//
//  SSAppDelegate.h
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SSViewController;

@interface SSAppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SSViewController *viewController;

@property (strong, nonatomic) UINavigationController *navigationController;

@end
