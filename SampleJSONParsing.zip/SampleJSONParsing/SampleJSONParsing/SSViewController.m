//
//  SSViewController.m
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//


#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) //1
#define kLatestKivaLoansURL [NSURL URLWithString: @"http://api.kivaws.org/v1/loans/search.json?status=fundraising"]
#import "SSViewController.h"
#import "SSSecViewController.h"
@interface SSViewController ()

@end

@implementation SSViewController
@synthesize demoTableView;
@synthesize demoArray;
@synthesize democustomcell;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.title=@"Customers List";
    
    demoArray=[[NSMutableArray alloc]init];
    dispatch_async(kBgQueue, ^{
        NSData* data = [NSData dataWithContentsOfURL: kLatestKivaLoansURL];
        [self performSelectorOnMainThread:@selector(fetchedData:) withObject:data waitUntilDone:YES];
    });

    
}

- (void)fetchedData:(NSData *)responseData
{
    //parse out the json data
    NSError* error;
    NSDictionary* jsonDictonary = [NSJSONSerialization JSONObjectWithData:responseData 
                                                         options:kNilOptions
                                                           error:&error];
     
    NSArray *jsonArray=[jsonDictonary objectForKey:@"loans"];
    
    for (int i=0; i<[jsonArray count]; i++)
    {
        
        NSDictionary *subDictionary=[jsonArray objectAtIndex:i];
        SSObject *myObj=[[SSObject alloc]init];
        
        myObj.nameString=[subDictionary valueForKey:@"name"];
        myObj.idString=[subDictionary valueForKey:@"id"];
        myObj.activityString=[subDictionary valueForKey:@"activity"];
        myObj.sectorString=[subDictionary valueForKey:@"sector"];
        myObj.useString=[subDictionary valueForKey:@"use"];

        NSDictionary *locationDictionary=[subDictionary valueForKey:@"location"];
        
        myObj.countryString=[locationDictionary valueForKey:@"country"];
        myObj.townString=[locationDictionary valueForKey:@"town"];
        
        myObj.loanAmountString=[subDictionary valueForKey:@"loan_amount"];
        myObj.PostedString=[subDictionary valueForKey:@"posted_date"];
        
        [demoArray addObject:myObj];
        
        NSLog(@"Demoarray count is %d",demoArray.count);
    }
    
    [demoTableView reloadData];
    
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  [demoArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static NSString *CellIdentifier = @"cell";
    
    SSDemoCell *cell=(SSDemoCell *)[self.demoTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell==nil)
    {
        [[NSBundle mainBundle] loadNibNamed:@"SSDemoCell" owner:self options:nil];
        cell=self.democustomcell;
    }
    
    SSObject *myObj=[demoArray objectAtIndex:indexPath.row];
    
    cell.nameLabel.text=myObj.nameString;
    cell.activityLabel.text=myObj.activityString;
    
    NSLog(@"Id str is %@",myObj.idString);
   cell.idLabel.text= [NSString stringWithFormat:@"%@",  myObj.idString];
    
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SSSecViewController *sssview=[[SSSecViewController alloc]initWithNibName:@"SSSecViewController" bundle:nil];
    
    sssview.secObj=[self.demoArray objectAtIndex:indexPath.row];
    
    [self.navigationController pushViewController:sssview animated:YES];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
