//
//  SSWebViewController.m
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSWebViewController.h"

@interface SSWebViewController ()

@end

@implementation SSWebViewController
@synthesize xmlWebView;
@synthesize webURlStr;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}





- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self startWebViewLoad];
}




-(void)startWebViewLoad{
    
	//NSString *urlAddress = @"http://www.google.com";
	NSString *urlAddress = @"http://cagt.bu.edu/page/IPhone-summer2010-wiki_problemsandsolutions";
	//Create a URL object.
	NSURL *url = [NSURL URLWithString:urlAddress];
	
	//URL Requst Object
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	
	//Load the request in the UIWebView.
	[xmlWebView loadRequest:requestObj];
	
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
