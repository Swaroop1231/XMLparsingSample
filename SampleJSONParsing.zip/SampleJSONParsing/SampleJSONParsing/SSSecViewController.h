//
//  SSSecViewController.h
//  SampleJSONParsing
//
//  Created by Varma Bhupatiraju on 8/21/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSObject.h"

@interface SSSecViewController : UIViewController

@property(nonatomic,strong) IBOutlet UILabel *sectorString;
@property(nonatomic,strong) IBOutlet UILabel  *useString;
@property(nonatomic,strong) IBOutlet UILabel  *countryString;
@property(nonatomic,strong) IBOutlet UILabel  *townString;
@property(nonatomic,strong) IBOutlet UILabel  *PostedString;
@property(nonatomic,strong) IBOutlet UILabel  *loanAmountString;

@property(nonatomic,strong) SSObject  *secObj;
-(void)getDetails;
@end
