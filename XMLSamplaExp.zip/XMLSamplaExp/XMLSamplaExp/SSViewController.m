//
//  SSViewController.m
//  XMLSamplaExp
//
//  Created by Varma Bhupatiraju on 8/5/13.
//  Copyright (c) 2013 Stellent Soft Pvt Ltd. All rights reserved.
//

#import "SSViewController.h"
#import "SSWebViewController.h"

@interface SSViewController ()

@end

@implementation SSViewController
@synthesize xmlTblView;
@synthesize myObj;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    appdelegate=(SSAppDelegate *)[[UIApplication sharedApplication]delegate];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   return  [appdelegate.testMutableArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
    }
    
    myObj=[appdelegate.testMutableArray objectAtIndex:indexPath.row];
    cell.textLabel.text=myObj.titleSr;
    cell.detailTextLabel.text=myObj.descStr;
    

    return cell;
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    myObj=[appdelegate.testMutableArray objectAtIndex:indexPath.row];
    
    SSWebViewController *webview=[[SSWebViewController alloc]initWithNibName:@"SSWebViewController" bundle:nil];
    
    webview.webURlStr=myObj.linkStr;
    
    [self.navigationController pushViewController:webview animated:YES];
    
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
